export const apiUrls = {
  authServiceApi: 'http://localhost:8800/api/auth/'
}
